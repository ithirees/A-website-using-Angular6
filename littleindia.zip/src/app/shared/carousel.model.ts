export class carouselList {
    public imagePath:string;
    public imageDescription:string;

    constructor(imgPath:string, imgDesc:string)
    {
        this.imagePath = imgPath;
        this.imageDescription = imgDesc;
    }
}