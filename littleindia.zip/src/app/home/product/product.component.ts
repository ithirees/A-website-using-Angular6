import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cuisine-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
